/*
 * PII Guard — background service worker (Manifest V3)
 * ---------------------------------------------------
 * ALL network calls to the Python engine happen here. In MV3, content
 * scripts CANNOT make cross-origin requests (Loophole 3) — they message
 * this worker, and the worker fetches localhost using host_permissions.
 *
 * Messages handled:
 *   {type: "PII_CHECK", text, resume_mode}  ->  {ok, data} | {ok:false, error}
 *
 * Error codes returned to content.js:
 *   "unreachable"  — server.py is not running (fail-closed kicks in)
 *   "timeout"      — engine did not answer within REQUEST_TIMEOUT_MS
 *   "HTTP <code>"  — server answered with an error
 */

// Change this if you run server.py on another port — and update the matching
// pattern in manifest.json host_permissions.
const API_BASE = "<<<PASTE_THE_COPIED_CLOUDFLARE_URL_HERE>>>";  // Replace "<<<PASTE_THE_COPIED_CLOUDFLARE_URL_HERE>>>" with your new Cloudflare URL (keep the quotes).
const REQUEST_TIMEOUT_MS = 15000;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== "PII_CHECK") return; // not for us

  (async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const res = await fetch(`${API_BASE}/redact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: message.text,
          resume_mode: Boolean(message.resume_mode),
        }),
        signal: controller.signal,
      });
      clearTimeout(timer);

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        sendResponse({ ok: false, error: body.error || `HTTP ${res.status}` });
        return;
      }
      sendResponse({ ok: true, data: await res.json() });
    } catch (err) {
      clearTimeout(timer);
      const reason =
        err && err.name === "AbortError" ? "timeout" : "unreachable";
      sendResponse({ ok: false, error: reason });
    }
  })();

  return true; // keep the message channel open for the async sendResponse
});
