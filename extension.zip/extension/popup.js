/*
 * PII Guard — popup logic
 * -----------------------
 * 1. Master On/Off toggle  -> chrome.storage.local.enabled
 *    (content scripts watch it via chrome.storage.onChanged)
 * 2. Status dot            -> pings GET /health on the local engine
 * 3. Stats                 -> counters written by content.js after each scan
 *    (only aggregate numbers are ever stored — never message content)
 */

const API_BASE = "<<<PASTE_THE_COPIED_CLOUDFLARE_URL_HERE>>>";  // Replace "<<<PASTE_THE_COPIED_CLOUDFLARE_URL_HERE>>>" with your new Cloudflare URL (keep the quotes).

const $ = (sel) => document.querySelector(sel);

function renderToggle(enabled) {
  $("#master-toggle").checked = enabled;
}

function renderStats(stats) {
  $("#stat-scanned").textContent = stats.scanned;
  $("#stat-redacted").textContent = stats.redacted;
}

async function pingServer() {
  const dot = $("#status-dot");
  const label = $("#status-label");
  dot.className = "dot pending";
  label.textContent = "Checking engine…";

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3000);
  try {
    const res = await fetch(`${API_BASE}/health`, { signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    dot.className = "dot online";
    label.textContent = "Engine online · 127.0.0.1:5000";
  } catch {
    dot.className = "dot offline";
    label.textContent = "Engine offline — sends blocked";
  } finally {
    clearTimeout(timer);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(
    { enabled: true, resume_mode: false, stats: { scanned: 0, redacted: 0 } },
    (res) => {
      renderToggle(res.enabled !== false);
      document.querySelector("#resume-toggle").checked = res.resume_mode === true;
      renderStats(res.stats || { scanned: 0, redacted: 0 });
      pingServer();
    }
  );

  document.querySelector("#master-toggle").addEventListener("change", (e) => {
    chrome.storage.local.set({ enabled: e.target.checked });
  });

  document.querySelector("#resume-toggle").addEventListener("change", (e) => {
    chrome.storage.local.set({ resume_mode: e.target.checked });
  });

  // live-update while the popup is open
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.enabled) renderToggle(changes.enabled.newValue !== false);
    if (changes.resume_mode) {
      document.querySelector("#resume-toggle").checked = changes.resume_mode.newValue === true;
    }
    if (changes.stats) renderStats(changes.stats.newValue || { scanned: 0, redacted: 0 });
  });
});