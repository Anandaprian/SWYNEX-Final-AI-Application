/*
 * PII Guard — content script (runs on ChatGPT, Claude, Gemini)
 * ============================================================
 * Lifecycle of every message:
 *   1. User presses Enter (no Shift) or clicks the Send button.
 *   2. We cancel the event BEFORE the site's JS sees it — the listeners run
 *      in the CAPTURE phase on `document`, so we always win the race against
 *      React's root-level handlers (Loophole 2).
 *   3. The text goes content.js -> background.js -> POST /redact on
 *      localhost:5000 (content scripts can't fetch cross-origin in MV3).
 *   4. The redacted text is written back into the editor. Rich editors are
 *      contenteditable divs, so we use execCommand (Loophole 1) — plus the
 *      native value setter for real <textarea> editors (Gemini).
 *   5. We programmatically click Send. The isProcessing flag + isTrusted
 *      check stop that click from being intercepted again (Loophole 5).
 *   6. FAIL-CLOSED: if the engine is unreachable or the rewrite fails,
 *      the message is NOT sent — the user sees a red toast instead.
 *
 * Debug hook: window.__piiGuardLastToast = {kind, text} (also used by the
 * E2E test suite; the toast itself lives inside a closed Shadow DOM).
 */
(() => {
  "use strict";

  /* =====================================================================
   * SITES — THE SELECTOR REGISTRY
   * ---------------------------------------------------------------------
   * This is the ONLY place you need to touch when a site redesigns its
   * composer. Each entry maps a hostname to:
   *   input : selectors for the chat editor (tried in order; the last
   *           VISIBLE match wins, because the main composer sits at the
   *           bottom of the DOM on all three sites)
   *   send  : selectors for the send button (tried in order)
   *
   * Notes (as of this build):
   *   ChatGPT : #prompt-textarea is a ProseMirror contenteditable div,
   *             send button carries data-testid="send-button".
   *   Claude  : ProseMirror div, send button is aria-label="Send message".
   *   Gemini  : has used both a Quill-style editor and a real <textarea>;
   *             both selectors are listed, plus aria-label'd send button.
   * If every selector fails, FALLBACK_INPUT / FALLBACK_SEND below still
   * give the extension a chance to work after a redesign.
   * ===================================================================== */
  const SITES = {
    "chatgpt.com": {
      input: [
        "#prompt-textarea",                          // current composer
        'div.ProseMirror[contenteditable="true"]',   // ProseMirror fallback
        'textarea[data-id="root"]',                  // legacy textarea composer
      ],
      send: [
        'button[data-testid="send-button"]',
        'button[aria-label*="Send" i]',
      ],
    },
    "chat.openai.com": { alias: "chatgpt.com" },      // legacy domain (redirects)

    "claude.ai": {
      input: [
        'div.ProseMirror[contenteditable="true"]',
        'div[contenteditable="true"]',
      ],
      send: [
        'button[aria-label="Send message"]',
        'button[aria-label*="Send" i]',
      ],
    },

    "gemini.google.com": {
      input: [
        'rich-textarea div[contenteditable="true"]', // rich editor era
        "rich-textarea textarea",                    // textarea era
        'div.ql-editor[contenteditable="true"]',     // Quill era
        "textarea",
      ],
      send: [
        'button[aria-label="Send message"]',
        "button.send-button",
        'button[aria-label*="Send" i]',
      ],
    },
  };

  // Generic last-resort selectors (used when the host isn't in SITES or all
  // site-specific selectors have rotted after a redesign).
  const FALLBACK_INPUT = ['div[contenteditable="true"]', "textarea"];
  const FALLBACK_SEND = [
    'button[data-testid="send-button"]',
    'button[aria-label*="send" i]',
  ];

  function siteConfig() {
    const host = location.hostname;
    for (const [domain, conf] of Object.entries(SITES)) {
      if (host === domain || host.endsWith("." + domain)) {
        return conf.alias ? SITES[conf.alias] : conf;
      }
    }
    return null;
  }

  /* =====================================================================
   * State
   * ===================================================================== */

  let enabled = true;       // master toggle (cached — storage reads are async)
  let resumeMode = false;   // resume toggle (cached)
  let isProcessing = false; // re-entrancy guard (Loophole 5)

  chrome.storage.local.get({ enabled: true, resume_mode: false }, (res) => {
    enabled = res.enabled !== false;
    resumeMode = res.resume_mode === true;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.enabled) {
      enabled = changes.enabled.newValue !== false;
    }
    if (changes.resume_mode) {
      resumeMode = changes.resume_mode.newValue === true;
    }
  });

  /* =====================================================================
   * DOM helpers
   * ===================================================================== */

  // Last VISIBLE match wins: on all three sites the main composer is the
  // final editor in the DOM (edit-message boxes appear earlier in the tree).
  function queryVisible(selector) {
    const nodes = document.querySelectorAll(selector);
    for (let i = nodes.length - 1; i >= 0; i--) {
      if (nodes[i].getClientRects().length) return nodes[i];
    }
    return null;
  }

  function editorKind(el) {
    if (!el) return null;
    if (el.isContentEditable) return "contenteditable";
    if (el.tagName === "TEXTAREA") return "textarea";
    if (el.tagName === "INPUT") return "input";
    return null;
  }

  function getEditor() {
    const conf = siteConfig();
    const selectors = [...((conf && conf.input) || []), ...FALLBACK_INPUT];
    for (const sel of selectors) {
      const el = queryVisible(sel);
      const kind = editorKind(el);
      if (kind) return { el, kind };
    }
    return null;
  }

  function getSendButton() {
    const conf = siteConfig();
    const selectors = [...((conf && conf.send) || []), ...FALLBACK_SEND];
    for (const sel of selectors) {
      const el = queryVisible(sel);
      if (el && !el.disabled && el.getAttribute("aria-disabled") !== "true") {
        return el;
      }
    }
    return null;
  }

  // Is `a` within a few ancestor hops of `b`? Used to make sure the clicked
  // "Send" button belongs to the composer we scanned (and not, say, a
  // "Send us feedback" button somewhere else on the page).
  function near(a, b, hops = 6) {
    let p = a;
    for (let i = 0; i <= hops && p; i++, p = p.parentElement) {
      if (p === b || p.contains(b)) return true;
    }
    return false;
  }

  /* =====================================================================
   * Reading & WRITING the editor (Loophole 1: rich-text editors)
   * ===================================================================== */

  function getText(editor) {
    return editor.kind === "contenteditable"
      ? editor.el.innerText
      : editor.el.value || "";
  }

  function setText(editor, newText) {
    const { el, kind } = editor;
    el.focus();

    if (kind === "contenteditable") {
      // 1) Select ALL existing content so the insert REPLACES it
      //    (insertText alone would just append at the caret).
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);

      // 2) Insert line by line. execCommand fires proper `beforeinput`
      //    events, which is what ProseMirror/Quill editors actually listen
      //    to — a plain `.innerText = ...` assignment would be ignored.
      let ok = true;
      const lines = newText.split("\n");
      lines.forEach((line, i) => {
        if (i > 0 && !document.execCommand("insertLineBreak")) ok = false;
        if (line.length && !document.execCommand("insertText", false, line)) {
          ok = false;
        }
      });

      // 3) Ancient-engines fallback: brute-force + synthetic input event.
      if (!ok) {
        el.textContent = newText;
        el.dispatchEvent(new InputEvent("input", { bubbles: true }));
      }
    } else {
      // Real <textarea>/<input> (Gemini): use the NATIVE value setter, or
      // React's onChange will never fire (el.value = ... is swallowed).
      const proto = kind === "input"
        ? window.HTMLInputElement.prototype
        : window.HTMLTextAreaElement.prototype;
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value").set;
      nativeSetter.call(el, newText);
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }

  /* =====================================================================
   * Interception — capture phase, always ahead of the site (Loophole 2)
   * ===================================================================== */

  function isPlainEnter(e) {
    return (
      e.key === "Enter" &&
      !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey &&
      !e.isComposing // don't break IME composition (Indic input methods)
    );
  }

  document.addEventListener(
    "keydown",
    (e) => {
      if (!isPlainEnter(e)) return;
      if (!e.isTrusted) return;          // synthetic events pass through
      if (isProcessing) {                // mid-redaction: swallow the key so
        e.preventDefault();              // the message can't double-send
        e.stopPropagation();
        return;
      }
      if (!enabled) return;              // OFF: zero interference

      const editor = getEditor();
      if (!editor) return;
      // Only hijack Enter when it happened INSIDE the composer — never in
      // search boxes, modals or other inputs on the page.
      if (e.target !== editor.el && !editor.el.contains(e.target)) return;

      const text = getText(editor);
      if (!text.trim()) return;          // empty box: normal behaviour

      // Cancel BEFORE React sees the key. stopImmediatePropagation keeps
      // other document-level capture listeners from re-handling it too.
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      isProcessing = true;
      guardAndSend(editor);
    },
    true // CAPTURE PHASE — critical
  );

  document.addEventListener(
    "click",
    (e) => {
      if (!e.isTrusted) return;          // our own programmatic click passes
      if (isProcessing) {                // user re-clicks while busy: swallow
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (!enabled) return;
      if (!(e.target instanceof Element)) return;

      const conf = siteConfig();
      const selectors = [...((conf && conf.send) || []), ...FALLBACK_SEND];
      const btn = e.target.closest(selectors.join(","));
      if (!btn || btn.disabled) return;

      const editor = getEditor();
      if (!editor) return;
      if (!near(btn, editor.el)) return; // some other Send button on the page

      const text = getText(editor);
      if (!text.trim()) return;

      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      isProcessing = true;
      guardAndSend(editor);
    },
    true // CAPTURE PHASE — critical
  );

  /* =====================================================================
   * Scan -> rewrite -> re-send (fail-closed)
   * ===================================================================== */

  const SEND_DELAY_MS = 120;  // let React enable the send button after rewrite
  const COOLDOWN_MS = 250;    // grace after send so Enter can't double-fire

  async function guardAndSend(editor) {
    const original = getText(editor);

    let response;
    try {
      response = await chrome.runtime.sendMessage({
        type: "PII_CHECK",
        text: original,
        resume_mode: resumeMode,
      });
    } catch {
      response = { ok: false, error: "extension-reloaded" };
    }

    if (!response || !response.ok) {
      // FAIL-CLOSED: engine unreachable/errored -> block the send.
      // The original text stays in the box; nothing is transmitted.
      toast("error", `PII Guard: ${describeError(response && response.error)} — message NOT sent.`);
      isProcessing = false;
      return;
    }

    const data = response.data;

    if (typeof data.redacted_text === "string" && data.redacted_text !== original) {
      try {
        setText(editor, data.redacted_text);
      } catch {
        toast("error", "PII Guard could not rewrite the chat box — message NOT sent.");
        isProcessing = false;
        return;
      }

      // Safety net: verify the rewrite really happened before sending
      // (editors can silently swallow programmatic edits).
      const now = getText(editor).replace(/\s+$/, "");
      if (now !== data.redacted_text.replace(/\s+$/, "")) {
        toast("error", "Chat box rewrite could not be verified — message NOT sent.");
        isProcessing = false;
        return;
      }

      const n = data.redaction_count;
      toast("success", `PII redacted — ${n} item${n === 1 ? "" : "s"} masked. Sending…`);
      if (data.degraded) {
        toast("warn", "Engine is in regex-fallback mode.");
      }
    } else {
      toast("clean", "No PII detected. Sending…");
    }

    bumpStats(data);

    setTimeout(() => {
      try {
        triggerSend(editor);
      } catch {
        // Editor still holds the REDACTED text — the user can press Enter.
        toast("warn", "Auto-send failed — press Enter to send the redacted message.");
      } finally {
        setTimeout(() => { isProcessing = false; }, COOLDOWN_MS);
      }
    }, SEND_DELAY_MS);
  }

  function triggerSend(editor) {
    const btn = getSendButton();
    if (btn) {
      btn.click(); // synthetic click — our listener ignores !isTrusted events
      return;
    }
    // No send button (e.g. button hidden while a response streams in):
    // simulate an Enter keydown on the editor for the site to handle.
    editor.el.dispatchEvent(
      new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        bubbles: true,
        cancelable: true,
      })
    );
  }

  function describeError(code) {
    switch (code) {
      case "unreachable":
        return "cannot reach the engine (is server.py running on 127.0.0.1:5000?)";
      case "timeout":
        return "engine timed out";
      case "extension-reloaded":
        return "extension was reloaded — press Enter again";
      default:
        return code || "unknown error";
    }
  }

  /* =====================================================================
   * Stats (aggregate counters only — message content is never stored)
   * ===================================================================== */

  function bumpStats(data) {
    chrome.storage.local.get({ stats: { scanned: 0, redacted: 0 } }, (res) => {
      const stats = res.stats || { scanned: 0, redacted: 0 };
      stats.scanned += 1;
      stats.redacted += (data && data.redaction_count) || 0;
      chrome.storage.local.set({ stats });
    });
  }

  /* =====================================================================
   * Toast notifications — closed Shadow DOM (spec remark #3)
   * ---------------------------------------------------------------------
   * A plain injected <div> gets restyled/eaten by ChatGPT's aggressive CSS.
   * This toast lives inside a closed shadow root with `all: initial`, so
   * page styles cannot reach it.
   * ===================================================================== */

  let toastBox = null; // lives inside the closed shadow root

  function ensureToastHost() {
    if (toastBox) return;
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;";
    const shadow = host.attachShadow({ mode: "closed" });

    const style = document.createElement("style");
        const sheet = new CSSStyleSheet();
    sheet.replaceSync(`
      :host { all: initial; }
      * {
        all: initial; box-sizing: border-box;
        font-family: -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      }
      .toast {
        display: block; max-width: 320px; margin-bottom: 8px;
        padding: 10px 14px; border-radius: 10px;
        color: #fff; font-size: 13px; line-height: 1.45; text-align: left;
        background: #1f2430; border-left: 4px solid #64748b;
        box-shadow: 0 6px 24px rgba(0, 0, 0, .35);
        animation: pii-in .18s ease-out;
      }
      .toast.success { border-left-color: #22c55e; }
      .toast.clean   { border-left-color: #38bdf8; }
      .toast.warn    { border-left-color: #f59e0b; }
      .toast.error   { border-left-color: #ef4444; }
      @keyframes pii-in {
        from { opacity: 0; transform: translateY(-6px); }
        to   { opacity: 1; transform: none; }
      }
    `);

    toastBox = document.createElement("div");
    shadow.adoptedStyleSheets = [sheet];
    shadow.appendChild(toastBox);
    (document.body || document.documentElement).appendChild(host);
  }

  function toast(kind, message) {
    ensureToastHost();
    const el = document.createElement("div");
    el.className = `toast ${kind}`;
    el.textContent = message; // textContent — no HTML injection possible
    toastBox.appendChild(el);
    // Debug/testing hook (the shadow root itself is closed to the page).
    window.__piiGuardLastToast = { kind, text: message, at: Date.now() };
    setTimeout(() => el.remove(), kind === "error" ? 6000 : 3000);
  }
})();
